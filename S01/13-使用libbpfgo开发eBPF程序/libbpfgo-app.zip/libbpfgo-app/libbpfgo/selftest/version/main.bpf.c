//+build ignore
#ifdef asm_inline
#undef asm_inline
#define asm_inline asm
#endif

